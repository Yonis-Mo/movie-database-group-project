<?php
echo <<<_END
</main>
</body>

<footer id="bottom-footer">
A-Team - 2022 - Hello Movies! .com 
<script async src="js/api_call.js"></script>
</footer>
</html>
_END;
?>