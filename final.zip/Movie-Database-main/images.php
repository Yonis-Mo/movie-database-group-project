<?php

function readMovies(){

$row = 0;

if (($h = fopen("archive/movies_metadata.csv", "r")) !== FALSE) { //path for .csv file

// Convert each line into the local $data variable

    while (($data = fgetcsv($h, 1000, ",")) !== FALSE)

    {

        $row++;

        if($row != 1){//skips the first line(header) of csv file

            $tmdb_id = isset($data[5]) ? htmlentities($data[5], ENT_QUOTES) : "";

            $imdb_id = isset($data[6]) ? htmlentities($data[6], ENT_QUOTES) : "";

            $title = isset($data[20]) ? htmlentities($data[20], ENT_QUOTES) : htmlentities($data[8], ENT_QUOTES);//uses OG Title instead
            $overview = isset($data[9]) ? htmlentities($data[9], ENT_QUOTES) : "";

            $revenue = isset($data[15]) ? htmlentities($data[15], ENT_QUOTES) : "";

            $adult = isset($data[0]) ? htmlentities($data[0], ENT_QUOTES) : "";

            $budget = isset($data[2]) ? htmlentities($data[2], ENT_QUOTES) : "";

            $popularity = isset($data[10]) ? htmlentities($data[10], ENT_QUOTES) : "";

            $date = isset($data[14]) ? htmlentities($data[14], ENT_QUOTES) : "";


            $runtime = isset($data[16]) ? htmlentities($data[16], ENT_QUOTES) : "";                
            $tagline = isset($data[19]) ? htmlentities($data[19], ENT_QUOTES) : "";               
            $voteavg = isset($data[22]) ? htmlentities($data[22], ENT_QUOTES) : "";               
            $votecount = isset($data[23]) ? htmlentities($data[23], ENT_QUOTES) : ""; $genres = array();

$gens = str_replace("'", "\"", $data[3]);   //single quotes in data won't be read thru json. Need to be replaced with double quotes

$gens_arr = json_decode($gens, true);

foreach($gens_arr as $item) { //foreach element in $arr

    array_push($genres, $item['name']);

}

$genres = json_encode($genres);

//INSERT INTO DB

$sql = "INSERT INTO movies

(TMDB_ID, IMDB_ID, Title, Overview, Revenue, Adult, Budget, Genres, Popularity, ReleaseDate, Runtime, Tagline, VoteAvg, VoteCount) VALUES

(?,?,?,?,?,?,?,?,?,?,?,?,?,?);";

$stmt = $conn->prepare($sql);

$stmt->bind_param("isssiiisdsisdi",

$tmdb_id, $imdb_id, $title, $overview, $revenue, $adult, $budget, $genres,

$popularity, $date, $runtime, $tagline, $voteavg, $votecount);

if ($stmt->execute()) {

    echo "1";

}else{

    echo ("Error updating record: " . $conn->error. "ROW: ".$row."<br>");

}

}

}

// Close the file

fclose($h);

}

}



?>