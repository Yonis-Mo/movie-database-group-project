// javascript file
// darkmode and accessiblity should be coded
