function pics() {
    //find img tags
    //get id's -> titles
    //call api
    //change source to be returned source
    var img_tags = document.getElementsByTagName("img");
    for (let i = 0; i, img_tags.length; i++) {
        var img_tag_id = img_tags[i].id;
        var title = img_tag_id.replace(/_/g, " ");

        call(img_tag_id, title);
    }









    //  var title = "Hot Fuzz";
    //  call(title);
}


const call = async(id, title) => {
    const response = await fetch("https://api.themoviedb.org/3/search/movie?api_key=15d2ea6d0dc1d476efbca3eba2b9bbfb&query=" + title);
    const myJson = await response.json(); //extract JSON from the http response
    // do something with myJson

    if (myJson.total_results > 0) {
        let path = "http://image.tmdb.org/t/p/w500" + myJson.results[0].poster_path;
        //<img src="http://image.tmdb.org/t/p/w500" + json.results[0].poster_path 
        document.getElementById(id).src = path;

    } else {
        console.log("Sorry! Couldn't find a poster");
    }


}

window.onload = pics;