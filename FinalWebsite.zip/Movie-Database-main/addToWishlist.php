<?php

require_once('credentials.php');
include 'header.php';

if(isset($_POST['id']))
{
// $mid = $_POST['id'];

$sql = "SELECT * FROM users WHERE ID = ?;";
$stmt = $conn->prepare($sql);

$mid = $_SESSION['ID'];
$new_film_to_wishlist = $_POST['id'];  //Movie_ID
$stmt->bind_param("i", $mid);

$stmt->execute();
$result = $stmt->get_result();


if($result->num_rows > 0){
    $new_wishlist = array();
    while ($row = $result->fetch_assoc()) {

        $current_wishlist = json_decode($row['Wishlist']);

        if(is_null($current_wishlist)){

            echo "No Wishlist";
            array_push($new_wishlist, $new_film_to_wishlist);
        }else{
            for($i = 0; $i < count($current_wishlist); $i++){
                array_push($new_wishlist, $current_wishlist[$i]);

            }
            array_push($new_wishlist, $new_film_to_wishlist);

        }
    }

}else{
  echo "Sorry! We couldn't find any films of that genre";
}

$sql = "UPDATE users SET Wishlist = ? WHERE ID = ?;";
$stmt = $conn->prepare($sql);

$new_wishlist = json_encode($new_wishlist);
echo($new_wishlist);

$stmt->bind_param("si", $new_wishlist, $mid);

if($stmt->execute()){
    header("location: user.php");
}else{
    echo "Error Adding Wishlist";
}
}


?>