<?php
echo <<<_END
</main>
</body>

<footer id="bottom-footer">
A-Team - 2022 - (website name) .com 
<script async src="script/dom.js"></script>
</footer>
</html>
_END;
?>
watch Trailer or free movies// website name 