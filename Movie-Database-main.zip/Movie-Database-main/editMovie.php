<?php
// add PHP include for the header and credentials for database and validate info for verification of data
include 'header.php';
require_once "helper.php";
require_once "credentials.php";

//Set some empty values
$fileSaveLocation= "";
$titleError= ""; 
$contentError= ""; 
$errors="";

$message = "Please ensure your posts contain between 2 and 20 characters for the title and 2 to 260 characters for the content"; 
// connect to the host
$connection = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);

// exit the script with a useful message if there was an error:
if (!$connection)
{
    die("Connection failed: " . $mysqli_connect_error);
}

//Create the form for editing the posts
if (isset($_POST['id']))
{
    $posts = $_POST['id'];
    echo <<<_END
    <div class='container-fluid'>
    <h3>Edit The Movie</h3>    
    <div class="form-group">
    <form action="#" method="post" name="editPost">
    <label for="Title">Title:</label><br>
    <input type="text" id="title" name="title" maxlength="16" size="16" placeholder="Title" required><br>
    <label for="content">Overview:</label><br>
    <input type="text" id="content" name="content" maxlength="260" size="30" placeholder="Please add a overview" required><br>
    <label for="content">Rating:</label><br>
    <input type="text" id="rating" name="rating" maxlength="2" size="30" placeholder="Please add a rating" required><br>
    </div>
    <button name= "validate" value="$posts" type= "submit"  class="btn">Submit</button>
    </form>
    </div>
_END;
}



// if form above is validated move to if statement to sanitise and validate data
if(isset($_POST['validate']))
{
    //get credentials for db
    require_once 'credentials.php';
    //grab new values from form 
    $titleEdited = $_POST['title'];
    $contentEdited = $_POST['content'];
    $ratingEdited = $_POST['rating'];
    $posts = $_POST['validate'];
    //sanitise and validate the new data
    $titleEdited = sanitise($titleEdited, $connection);
    $contentEdited = sanitise($contentEdited, $connection);
    $titleError = validateString($titleEdited, 2,20); 
    $contentError = validateString($contentEdited, 2, 260); 
    $errors=$titleError . $contentError;
    //attemp to connect to database 
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    
    // Attempt to connect. Return an error if not.
    if (!$connection)
    {
        die("Connection failed: " . $mysqli_connect_error);
    }

    // if errors is empty continue to insert data
    if ($errors == ""){
    //insert new data
    $query = "UPDATE movies SET Title = '$titleEdited', Overview = '$contentEdited', VoteAvg ='$ratingEdited' WHERE id = $posts";
    echo $query;
    $result = mysqli_query($connection,$query);

    
    //send user back to their posts page 
    if ($result)
    {
        // navigate back to the admin page:
        header('Location: admin.php');
    }
    //if major error destroy session and logout user 
    else
    {    
        session_destroy();
        include 'header.php';
        session_destroy();
        echo "<h4>Sorry, failed to edit post. You will be signed out</h4>";
        echo "[<a href='header.php'>Click here to go back</a>] ";
        $_SESSION["loggedIn"]=false;
        include 'footer.php';
    }
}
    //echo error message if data could not be entered
    echo $message;
    mysqli_close($connection);


    include 'footer.php';
}

?>